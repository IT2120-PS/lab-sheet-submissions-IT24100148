# IT2120 - Probability and Statistics - Lab Sheet 08
# Registration Number: IT24100148

setwd("C:\\Users\\J Kenath\\Desktop\\IT24100148_PS_Lab08")

# Using the provided laptop weights data
laptop_weights <- c(2.46, 2.45, 2.47, 2.71, 2.46, 2.05, 2.6, 2.42, 2.43, 2.53,
                    2.57, 2.85, 2.7, 2.53, 2.28, 2.2, 2.57, 2.89, 2.51, 2.47,
                    2.66, 2.06, 2.41, 2.65, 2.76, 2.43, 2.61, 2.57, 2.73, 2.17,
                    2.67, 2.05, 1.71, 2.32, 2.23, 2.76, 2.7, 2.13, 2.75, 2.2)

cat("=== IT2120 Lab Sheet 08 Solutions ===\n\n")
cat("Population Size:", length(laptop_weights), "\n\n")

# 1. Calculate population mean and population standard deviation
cat("1. POPULATION PARAMETERS:\n")
pop_mean <- mean(laptop_weights)
pop_sd <- sd(laptop_weights)
pop_var <- var(laptop_weights)

cat("   Population Mean (μ):", round(pop_mean, 4), "kg\n")
cat("   Population Standard Deviation (σ):", round(pop_sd, 4), "kg\n")
cat("   Population Variance (σ²):", round(pop_var, 4), "\n\n")

# 2. Draw 25 random samples of size 6 (with replacement)
cat("2. 25 RANDOM SAMPLES OF SIZE 6 (with replacement):\n")
set.seed(123) # For reproducible results

sample_means <- numeric(25)
sample_sds <- numeric(25)

for(i in 1:25) {
  # Draw sample with replacement
  sample_data <- sample(laptop_weights, size = 6, replace = TRUE)
  sample_means[i] <- mean(sample_data)
  sample_sds[i] <- sd(sample_data)
  cat("   Sample", sprintf("%2d", i), ": Mean =", round(sample_means[i], 4), 
      "kg, SD =", round(sample_sds[i], 4), "kg\n")
}

# 3. Calculate mean and standard deviation of the 25 sample means
cat("\n3. STATISTICS OF SAMPLE MEANS:\n")
mean_of_means <- mean(sample_means)
sd_of_means <- sd(sample_means)
var_of_means <- var(sample_means)

cat("   Mean of 25 Sample Means (x̄̄):", round(mean_of_means, 4), "kg\n")
cat("   Standard Deviation of Sample Means (σ_x̄):", round(sd_of_means, 4), "kg\n")
cat("   Variance of Sample Means (σ²_x̄):", round(var_of_means, 4), "\n\n")

# 4. Relationship analysis
cat("4. RELATIONSHIP ANALYSIS:\n")
cat("   True Population Mean (μ):", round(pop_mean, 4), "kg\n")
cat("   Mean of Sample Means (x̄̄):", round(mean_of_means, 4), "kg\n")
cat("   Difference:", round(abs(pop_mean - mean_of_means), 4), "kg\n")
cat("   True Population SD (σ):", round(pop_sd, 4), "kg\n")
cat("   SD of Sample Means (σ_x̄):", round(sd_of_means, 4), "kg\n")
cat("   Theoretical SD of Sample Means (σ/√n):", round(pop_sd/sqrt(6), 4), "kg\n\n")

# Calculate percentages for better comparison (FIXED VARIABLES)
mean_diff <- abs(pop_mean - mean_of_means)
mean_diff_percent <- (mean_diff / pop_mean) * 100

sd_theoretical <- pop_sd/sqrt(6)
sd_diff <- abs(sd_theoretical - sd_of_means)
sd_diff_percent <- (sd_diff / sd_theoretical) * 100

cat("5. STATISTICAL RELATIONSHIPS:\n")
cat("   A. Mean Comparison:\n")
cat("      - Population Mean (μ) =", round(pop_mean, 4), "kg\n")
cat("      - Mean of Sample Means (x̄̄) =", round(mean_of_means, 4), "kg\n")
cat("      - Difference =", round(mean_diff, 4), "kg (", round(mean_diff_percent, 2), "%)\n")
cat("      ✓ The mean of sample means is very close to the population mean\n")
cat("      ✓ This demonstrates that the sample mean is an UNBIASED ESTIMATOR\n\n")

cat("   B. Standard Deviation Comparison:\n")
cat("      - Population SD (σ) =", round(pop_sd, 4), "kg\n")
cat("      - SD of Sample Means (σ_x̄) =", round(sd_of_means, 4), "kg\n")
cat("      - Theoretical σ/√n =", round(sd_theoretical, 4), "kg\n")
cat("      - Difference =", round(sd_diff, 4), "kg (", round(sd_diff_percent, 2), "%)\n")
cat("      ✓ The SD of sample means follows the formula: σ_x̄ = σ/√n\n")
cat("      ✓ This illustrates the CENTRAL LIMIT THEOREM\n\n")

cat("   C. Key Statistical Principles Demonstrated:\n")
cat("      1. Law of Large Numbers: As sample size increases, sample mean → population mean\n")
cat("      2. Unbiased Estimator: E[x̄] = μ\n")
cat("      3. Standard Error: σ_x̄ = σ/√n\n")
cat("      4. The sampling distribution of means is approximately normal\n")

# Additional summary statistics
cat("\n6. ADDITIONAL SUMMARY:\n")
cat("   Population size (N):", length(laptop_weights), "\n")
cat("   Sample size (n): 6\n")
cat("   Number of samples: 25\n")
cat("   Population range:", round(min(laptop_weights), 4), "-", round(max(laptop_weights), 4), "kg\n")
cat("   Sample means range:", round(min(sample_means), 4), "-", round(max(sample_means), 4), "kg\n")

# Create a summary table
cat("\n7. SUMMARY TABLE:\n")
summary_table <- data.frame(
  Statistic = c("Population Mean (μ)", 
                "Mean of Sample Means (x̄̄)", 
                "Population SD (σ)", 
                "SD of Sample Means (σ_x̄)", 
                "Theoretical SE (σ/√n)"),
  Value = c(round(pop_mean, 4),
            round(mean_of_means, 4),
            round(pop_sd, 4),
            round(sd_of_means, 4),
            round(sd_theoretical, 4)),
  Units = rep("kg", 5)
)
print(summary_table)

# Save the results
results <- data.frame(
  Population_Mean = pop_mean,
  Mean_of_Sample_Means = mean_of_means,
  Population_SD = pop_sd,
  SD_of_Sample_Means = sd_of_means,
  Theoretical_SE = sd_theoretical,
  Mean_Difference = mean_diff,
  Mean_Difference_Percent = mean_diff_percent,
  SD_Difference = sd_diff,
  SD_Difference_Percent = sd_diff_percent
)

write.csv(results, "Lab08_Results_Summary.csv", row.names = FALSE)
cat("\nResults summary saved to 'Lab08_Results_Summary.csv'\n")

# Final conclusion
cat("\n8. CONCLUSION:\n")
cat("   The experiment successfully demonstrates:\n")
cat("   - The sample mean is an unbiased estimator of the population mean\n")
cat("   - The standard deviation of sample means follows σ_x̄ = σ/√n\n")
cat("   - Both relationships confirm fundamental principles of sampling theory\n")