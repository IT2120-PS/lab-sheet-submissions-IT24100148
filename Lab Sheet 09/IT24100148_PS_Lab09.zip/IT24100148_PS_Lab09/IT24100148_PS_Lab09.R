setwd("C:\\Users\\J Kenath\\Desktop\\IT24100148_PS_Lab09")

# Question 1: Testing if professors know 3 memes on average
cat("Question 1:\n")
meme_counts <- c(3, 7, 11, 0, 7, 0, 4, 5, 6, 2)
cat("Meme counts:", meme_counts, "\n")
test1 <- t.test(meme_counts, mu = 3)
print(test1)
cat("Conclusion: Since p-value (", test1$p.value, ") is", 
    ifelse(test1$p.value > 0.05, "greater than 0.05, we do not reject H0.", 
           "less than or equal to 0.05, we reject H0."), 
    "Therefore, the true average number of memes is",
    ifelse(test1$p.value > 0.05, "not significantly different from 3.\n\n", 
           "significantly different from 3.\n\n"))

# Question 2: Mouse weight analysis
cat("Question 2:\n")
# Part i: Test if mean weight is less than 25g
weight <- c(17.6, 20.6, 22.2, 15.3, 20.9, 21.0, 18.9, 18.9, 18.9, 18.2)
cat("Mouse weights:", weight, "\n")
test2 <- t.test(weight, mu = 25, alternative = "less")
print(test2)
cat("Conclusion: Since p-value (", test2$p.value, ") is", 
    ifelse(test2$p.value > 0.05, "greater than 0.05, we do not reject H0.", 
           "less than or equal to 0.05, we reject H0."), 
    "Therefore, the true mean weight is",
    ifelse(test2$p.value > 0.05, "not significantly less than 25g.\n", 
           "significantly less than 25g.\n"))

# Part ii: Extract individual components
cat("\nQuestion 2 - Part ii (Extracted values):\n")
cat("Test statistic:", test2$statistic, "\n")
cat("P-value:", test2$p.value, "\n")
cat("Confidence interval:", test2$conf.int, "\n\n")

# Question 3: Sugar level analysis
cat("Question 3:\n")
# Part i: Generate random numbers
set.seed(123) # For reproducible results
sugar_levels <- rnorm(30, mean = 9.8, sd = 0.05)
cat("Generated sugar levels (first 10 values):", sugar_levels[1:10], "...\n")

# Part ii: Test if mean sugar level is greater than 10
test3 <- t.test(sugar_levels, mu = 10, alternative = "greater")
print(test3)
cat("Conclusion: Since p-value (", test3$p.value, ") is", 
    ifelse(test3$p.value > 0.05, "greater than 0.05, we do not reject H0.", 
           "less than or equal to 0.05, we reject H0."), 
    "Therefore, the true mean sugar level is",
    ifelse(test3$p.value > 0.05, "not significantly greater than 10.\n\n", 
           "significantly greater than 10.\n\n"))



# Exercise Question
cat("EXERCISE QUESTION:\n")
# Part i: Generate random sample for baking time
set.seed(456) # For reproducible results
baking_times <- rnorm(25, mean = 45, sd = 2)
cat("Generated baking times (first 10 values):", baking_times[1:10], "...\n")

# Part ii: Test if average baking time is less than 46 minutes
exercise_test <- t.test(baking_times, mu = 46, alternative = "less")
print(exercise_test)
cat("Conclusion: Since p-value (", exercise_test$p.value, ") is", 
    ifelse(exercise_test$p.value > 0.05, "greater than 0.05, we do not reject H0.", 
           "less than or equal to 0.05, we reject H0."), 
    "Therefore, the average baking time is",
    ifelse(exercise_test$p.value > 0.05, "not significantly less than 46 minutes.", 
           "significantly less than 46 minutes."))