cat("EXERCISE: Vending Machine Snack Selection\n")
cat("==================================================\n\n")

# Actual data from the exercise
snack_data <- c(120, 95, 85, 100)
snack_names <- c("A", "B", "C", "D")

cat("Snack purchase data:\n")
for(i in 1:4) {
  cat("Snack", snack_names[i], ":", snack_data[i], "purchases\n")
}
cat("\n")

# Total purchases
total_purchases <- sum(snack_data)
cat("Total purchases for the week:", total_purchases, "\n\n")

cat("i. Hypotheses:\n")
cat("   Null Hypothesis (H0): Customers choose the four snack types with equal probability\n")
cat("   Alternative Hypothesis (H1): Customers do not choose the four snack types with equal probability\n")
cat("\n")

# Expected frequencies if equal probability
expected <- rep(total_purchases/4, 4)
cat("Expected frequencies if equal probability:\n")
for(i in 1:4) {
  cat("   Snack", snack_names[i], ":", round(expected[i], 2), "\n")
}
cat("\n")

# Chi-squared test for goodness of fit
cat("ii. Chi-squared test results:\n")
chi_test <- chisq.test(snack_data, p = rep(1/4, 4))

print(chi_test)
cat("\n")

cat("Chi-squared statistic:", round(chi_test$statistic, 4), "\n")
cat("Degrees of freedom:", chi_test$parameter, "\n")
cat("P-value:", chi_test$p.value, "\n\n")

cat("iii. Conclusion:\n")
if(chi_test$p.value < 0.05) {
  cat("   Since the p-value (", round(chi_test$p.value, 4), ") is less than 0.05,\n")
  cat("   we reject the null hypothesis. There is sufficient evidence\n")
  cat("   to suggest that customers do not choose snack types with equal probability.\n")
  cat("   The vending machine owner's claim is not supported by the data.\n")
} else {
  cat("   Since the p-value (", round(chi_test$p.value, 4), ") is greater than 0.05,\n")
  cat("   we fail to reject the null hypothesis. There is no sufficient evidence\n")
  cat("   to suggest that customers choose snack types differently.\n")
  cat("   The vending machine owner's claim is supported by the data.\n")
}

# =============================================================================
# Save Results to Files
# =============================================================================

# Save R script
script_name <- "IT[Your_Registration_Number]_Lab10.R"
writeLines(c(
  "# IT2120 - Probability and Statistics Lab Sheet 10",
  "# Chi-Squared Tests",
  "# Registration Number: IT[Your_Registration_Number]",
  "",
  "# Vending Machine Snack Selection Analysis",
  "snack_data <- c(120, 95, 85, 100)",
  "chi_test <- chisq.test(snack_data, p = rep(1/4, 4))",
  "print(chi_test)"
), script_name)

# Create results summary
results_file <- "IT[Your_Registration_Number]_Results.doc"
sink(results_file)

cat("IT2120 - Probability and Statistics Lab Sheet 10\n")
cat("Chi-Squared Tests - Homework Exercise Results\n")
cat("Registration Number: IT[Your_Registration_Number]\n")
cat("Date:", format(Sys.Date(), "%Y-%m-%d"), "\n\n")

cat("EXERCISE: Vending Machine Snack Selection\n")
cat("==================================================\n\n")

cat("Data:\n")
cat("Snack A: 120 purchases\n")
cat("Snack B: 95 purchases\n")
cat("Snack C: 85 purchases\n")
cat("Snack D: 100 purchases\n")
cat("Total: 400 purchases\n\n")

cat("Hypotheses:\n")
cat("H0: Customers choose the four snack types with equal probability\n")
cat("H1: Customers do not choose the four snack types with equal probability\n\n")

cat("Test Results:\n")
cat("Chi-squared statistic:", round(chi_test$statistic, 4), "\n")
cat("Degrees of freedom:", chi_test$parameter, "\n")
cat("P-value:", chi_test$p.value, "\n\n")

cat("Expected Frequencies:\n")
cat("Snack A: 100.0\n")
cat("Snack B: 100.0\n")
cat("Snack C: 100.0\n")
cat("Snack D: 100.0\n\n")

cat("Conclusion:\n")
if(chi_test$p.value < 0.05) {
  cat("REJECT the null hypothesis. There is sufficient evidence to conclude\n")
  cat("that customers do not choose snack types with equal probability.\n")
  cat("The vending machine owner's claim is NOT supported by the data.\n")
} else {
  cat("FAIL TO REJECT the null hypothesis. There is no sufficient evidence\n")
  cat("to conclude that customers choose snack types differently.\n")
  cat("The vending machine owner's claim IS supported by the data.\n")
}

sink()

cat("\nANALYSIS COMPLETE!\n")
cat("Files saved:\n")
cat("1.", script_name, "\n")
cat("2.", results_file, "\n")
cat("Please take screenshots of the output and include them in your Word document.\n")
cat("Zip both files and upload to the submission link.\n")